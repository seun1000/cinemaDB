const moment = require('moment')
const _ = require('lodash')
const vars = require('../../../../configs/vars')
const { Movies } = require(vars.dirs.models)

exports.index = async (req, res, next) => {
  const serverUrl = req.protocol + '://' + req.get('host')
  const staticUrl = req.protocol + '://' + req.get('host') + "/static"
  const movies = await Movies.find()
  let latest = _.sortBy(movies, "releaseDate")
  let topRated = _.sortBy(movies, "ratings")
  let upcoming = []

  // Format latest
  for(let i = 0; i < latest.length; i++) {
    let latestM = latest[i]
    let releaseDate = latestM.releaseDate
    let diff = moment().diff(new Date(releaseDate))
    let ratingStars = ''
    for(let j = 0; j < latestM.ratings; j++) {
      ratingStars += "⭐"
    }
    latest[i].ratingF = ratingStars + " ("+latestM.ratings+"/5)"
    if(!latestM.ratings) {
      latest[i].ratingF = "unknown"
    }
    console.log(ratingStars, latestM.title)
    if(latest[i].poster) {
      latest[i].img = serverUrl + "/v1/movies/getImage/" + latest[i].poster
    }
    if(diff < 0) {
      let check = _.find(upcoming, {_id: latest[i]._id})
      if(!check) {
        upcoming.push(latest[i])
      }
      latest.splice(i, 1)
    }
  }

  // Format top rated
  for(let i = 0; i < topRated.length; i++) {
    let topRatedM = topRated[i]
    let releaseDate = topRatedM.releaseDate
    let diff = moment().diff(new Date(releaseDate))
    let ratingStars = ''
    for(let j = 0; j < topRatedM.ratings; j++) {
      ratingStars += "⭐"
    }
    topRated[i].ratingF = ratingStars + " ("+topRatedM.ratings+"/5)"
    if(!topRatedM.ratings) {
      topRated[i].ratingF = "unknown"
    }
    if(topRated[i].poster) {
      topRated[i].img = serverUrl + "/v1/movies/getImage/" + topRated[i].poster
    }
    if(diff < 0) {
      let check = _.find(upcoming, {_id: topRated[i]._id})
      if(!check) {
        upcoming.push(topRated[i])
      }
      topRated.splice(i, 1)
    }
  }
  latest = latest.reverse()
  topRated = topRated.reverse()
  upcoming = _.sortBy(upcoming, 'releaseDate')
  return res.render('./home/home', { staticUrl, latest, topRated, upcoming })
}

exports.movieData = async (req, res, next) => {
  try {
    const serverUrl = req.protocol + '://' + req.get('host')
    const staticUrl = req.protocol + '://' + req.get('host') + "/static"
    let id = req.params.id
    let movie = await Movies.findOne( { _id: id } )
    movie.img = serverUrl + "/v1/movies/getImage/" + movie.poster
    let ratingStars = ''
    for(let j = 0; j < movie.ratings; j++) {
      ratingStars += "⭐"
    }
    movie.ratingF = ratingStars + " ("+movie.ratings+"/5)"
    movie.titleF = movie.title + " " + movie.ratingF
    return res.render('./home/movieData', { staticUrl, movie })
  }
  catch(e) {
    next(e)
  }
}
