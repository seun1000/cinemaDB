const mongoose = require('mongoose')
const bcrypt = require('bcryptjs')
const jwt = require('jwt-simple')
const moment = require('moment-timezone')
const vars = require('../../../configs/vars')

/**
 * User Schema
 * @private
 */
const userSchema = new mongoose.Schema({
  username: { type: String, required: true },
  password: { type: String, required: true },
  email: { type: String, required: true }
}, {
  timestamps: true,
})

/**
 * Add your
 * - pre-save hooks
 * - validations
 * - virtuals
 */
userSchema.pre('save', async function save(next) {
  try {
    if (!this.isModified('password')) return next();

    const rounds = vars.env === 'development' ? 1 : 10;

    const hash = await bcrypt.hash(this.password, rounds);
    this.password = hash;

    return next();
  } catch (error) {
    return next(error);
  }
});


/**
 * Methods
 */
userSchema.method({
  token() {
    const payload = {
      exp: moment().add(vars.jwtExpire, 'minutes').unix(),
      iat: moment().unix(),
      sub: this._id,
    };
    return jwt.encode(payload, vars.jwtSecret);
  },

  matchPassword(password) {
    return bcrypt.compareSync(password, this.password);
  }
})

/**
 * @typedef Movie
 */
module.exports = mongoose.model('users', userSchema);
