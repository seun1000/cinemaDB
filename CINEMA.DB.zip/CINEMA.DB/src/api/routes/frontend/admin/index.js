const express = require('express')
const { adminController } = require('../../../controllers/frontend')
const { AuthorizeJWTPage } = require('../../../middlewares')

const router = express.Router()
router.route('/login').get(adminController.login)
router.route('/movies').get(AuthorizeJWTPage, adminController.movies)
router.route('/movies/add').get(AuthorizeJWTPage, adminController.moviesAdd)
router.route('/movies/edit/:id').get(AuthorizeJWTPage, adminController.moviesEdit)

module.exports = router
