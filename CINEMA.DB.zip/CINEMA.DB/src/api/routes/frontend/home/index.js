const express = require('express')
const { homeController } = require('../../../controllers/frontend')
const { AuthorizeJWTPage } = require('../../../middlewares')

const router = express.Router()
router.route('/').get(homeController.index)
router.route('/movie/:id').get(homeController.movieData)

module.exports = router
