const express = require('express')
const validator = require ('express-validator')

const admin = require('./admin')
const home = require('./home')

const router = express.Router()

//APIS
router.use('/admin', admin)
router.use('/', home)

module.exports = router
