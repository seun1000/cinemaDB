const express = require('express')
const multer = require('multer')
const path = require('path')
const { movieController } = require('../../../controllers/v1')
const { AuthorizeJWT } = require('../../../middlewares')

// Configure multer
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
      cb(null, './uploads/')
    },
    filename: function (req, file, cb) {
      console.log(file)
      cb(null, file.originalname + '-' + Date.now() + path.extname(file.originalname))
  }
})

// upload object
const upload = multer({ storage: storage })

const router = express.Router()
router.route('/:id?').get(movieController.get)
router.route('/').post(AuthorizeJWT, upload.single('poster'), movieController.add)
router.route('/').put(AuthorizeJWT, upload.single('poster'), movieController.update)
router.route('/').delete(AuthorizeJWT, movieController.delete)
router.route('/getImage/:img').get(movieController.getImage)

module.exports = router
