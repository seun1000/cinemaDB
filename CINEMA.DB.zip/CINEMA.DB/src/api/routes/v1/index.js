const express = require('express')
const validator = require ('express-validator')

const sample = require('./sample')
const auth = require('./auth')
const movies = require('./movies')

const router = express.Router()

//API STATUS
router.get('/status', (req, res) => res.send('OK'));

//APIS
router.use('/sample', sample)
router.use('/auth', auth)
router.use('/movies', movies)

module.exports = router
