const axios = require('axios')

const express = require('express')
const validator = require ('express-validator')
const { sampleController } = require('../../../controllers/v1')

const router = express.Router()
router.route('/sendHelloJson').get(sampleController.sendHelloJson)
router.route('/sendHelloWorld').get(sampleController.sendHelloWorld)
router.route('/sendError').get(sampleController.sendError)

module.exports = router
