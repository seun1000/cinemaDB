const admin = require('./admin')
const home = require('./home')

module.exports = { adminController: admin, homeController: home }
