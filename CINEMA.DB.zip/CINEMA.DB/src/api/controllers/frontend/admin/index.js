const vars = require('../../../../configs/vars')
const { Movies } = require(vars.dirs.models)

exports.login = async (req, res, next) => {
  const staticUrl = req.protocol + '://' + req.get('host') + "/static"
  const user = req.user
  return res.render('./admin/login', { staticUrl, user })
}

exports.movies = async (req, res, next) => {
  const movies = await Movies.find()
  const staticUrl = req.protocol + '://' + req.get('host') + "/static"
  const user = req.user
  return res.render('./admin/movies', { movies, staticUrl, user })
}

exports.moviesAdd = async (req, res, next) => {
  const staticUrl = req.protocol + '://' + req.get('host') + "/static"
  const user = req.user
  return res.render('./admin/moviesAdd', { staticUrl, user })
}

exports.moviesEdit = async (req, res, next) => {
  let id = req.params.id
  let movie = await Movies.findOne( { _id: id } )
  const staticUrl = req.protocol + '://' + req.get('host') + "/static"
  const user = req.user
  return res.render('./admin/moviesEdit', { movie, nonce: res.locals.nonce, staticUrl, user })
}
