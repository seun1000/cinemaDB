const sample = require('./sample')
const auth = require('./auth')
const movies = require('./movies')

module.exports = {
  sampleController: sample,
  authController: auth,
  movieController: movies
}
