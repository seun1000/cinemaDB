const vars = require('../../../../configs/vars')
const { Forbidden } = require(vars.dirs.configs+"/errors")
exports.sendHelloWorld = async (req, res, next) => {
  try {
    return res.send('Hello World')
  }
  catch(e) {
    next(e)
  }
}

exports.sendHelloJson = async (req, res, next) => {
  try {
    return res.json( { hello: true } )
  }
  catch(e) {
    next(e)
  }
}

exports.sendError = async (req, res, next) => {
  try {
    throw new Forbidden('Some Error Occurred')
  }
  catch(e) {
    next(e)
  }
}
