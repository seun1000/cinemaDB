const Users = require('./users')
const Movies = require('./movies')

module.exports = { Users, Movies }
