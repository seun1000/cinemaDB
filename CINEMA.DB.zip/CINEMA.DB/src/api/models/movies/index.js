const mongoose = require('mongoose')
/**
 * User Schema
 * @private
 */
const movieSchema = new mongoose.Schema({
  title: { type: String, required: true },
  heads: { type: [Object] },
  actors: { type: [Object] },
  releaseDate: { type: String },
  ratings: { type: String },
  poster: { type: String },
}, {
  timestamps: true,
});


/**
 * @typedef Movie
 */
module.exports = mongoose.model('movies', movieSchema);
