const jwt = require('jwt-simple');
const vars = require('../../configs/vars')
const { Forbidden } = require(vars.dirs.configs+"/errors")
const { Users } = require(vars.dirs.models)

// JWT Secret
const JWTSecret = vars.jwtSecret

module.exports = async (req, res, next) => {
  try {
    let headers = req.headers
    let authToken = headers.authorization
    if(!authToken) {
      throw new Forbidden("Route not available")
    }
    let decoded = jwt.decode(authToken, JWTSecret)
    if(!decoded) {
      throw new Forbidden("Route not available")
    }
    let userId = decoded.sub
    let userData = await Users.findOne( { _id: userId } )
    req.user = userData
    next()
  }
  catch(e) {
    next(e)
  }
}
