const AuthorizeJWT = require('./authorizeJwt')
const AuthorizeJWTPage = require('./authorizeJwtPage')

module.exports = { AuthorizeJWT, AuthorizeJWTPage }
