const app = require('./configs/express')
const { port, env } = require('./configs/vars')
const http = require('http')
const logger = require('./configs/logger');
const mongoose = require('./configs/mongoose')
const Logger = require('./configs/terminalLogger');

// Terminal Logger
const serverLogger = new Logger('Server')

//console.log(vars)
// Create server
const server = http.createServer(app)

// Connect MongoDB
mongoose.connect()

// listen to requests
server.listen(port, () => serverLogger.logInfo(`Started on port ${port} (${env})`));
