const customError = require('custom-error')

const Forbidden = customError('Forbidden')
const Unauthorised = customError('Unauthorised')

module.exports = { Forbidden, Unauthorised }
