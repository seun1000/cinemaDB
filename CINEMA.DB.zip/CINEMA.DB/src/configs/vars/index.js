const path = require('path')
// import .env variables
require('dotenv').config()

module.exports = {
  env: process.env.NODE_ENV,
  port: process.env.PORT,
  logs: process.env.NODE_ENV === 'production' ? 'combined' : 'dev',
  domain: process.env.DOMAIN,
  jwtSecret: process.env.JWT_SECRET,
  jwtExpire: process.env.JWT_EXPIRE,
  mongo: {
    uri: process.env.MONGO_URI
  },
  dirs: {
    controllers: path.resolve(__dirname, "../../api/controllers/v1"),
    routes: path.resolve(__dirname, "../../api/routes/v1"),
    models: path.resolve(__dirname, "../../api/models"),
    validation: path.resolve(__dirname, "../../api/validations/v1"),
    configs: path.resolve(__dirname, "../"),
    project: path.resolve(__dirname, "../../../")
  }
};
