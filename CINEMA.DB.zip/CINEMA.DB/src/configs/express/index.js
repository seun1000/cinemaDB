const express = require('express')
const morgan = require('morgan')
const bodyParser = require('body-parser')
const compress = require('compression')
const methodOverride = require('method-override')
const cors = require('cors')
const helmet = require('helmet')
const cookieParser = require('cookie-parser')
const csp = require("helmet-csp")
const { logs, env } = require('../vars')
const v1Routes = require('../../api/routes/v1')
const frontendRoutes = require('../../api/routes/frontend')
const { ValidationError } = require('express-validation')
const Logger = require('../terminalLogger')
const expressLogger = require('../expressLogger')
const { Forbidden, Unauthorised } = require("../errors")
const crypto = require("crypto")

// Generate nonce
let nonce = crypto.randomBytes(16).toString("hex")

/**
* Express instance
* @public
*/
const app = express();
//GET /v1/staus 404 5.201 ms - 36
// request logging. dev: console | production: file
app.use(expressLogger('Express', logs))

// parse body params and attache them to req.body
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Parse cookies
app.use(cookieParser())

// gzip compression
app.use(compress());

// lets you use HTTP verbs such as PUT or DELETE
// in places where the client doesn't support it
app.use(methodOverride());

// secure apps by setting various HTTP headers
app.use(helmet());

// Secure CSP with nonce
app.use((req, res, next) => {
  res.locals.nonce = nonce
  csp({
    useDefaults: true,
    directives: {
      scriptSrc: ["'self'", `'nonce-${res.locals.nonce}'`],
    },
  })(req, res, next);
});

// enable CORS - Cross Origin Resource Sharing
app.use(cors());

// mount api v1 routes
app.use('/v1', v1Routes);

// Static resources
app.use('/static', express.static('./public'))

// Set templating engine
app.set('view engine', 'pug')

// Set default view folder
app.set('views', './view');

// mount frontend routes
app.use('/', frontendRoutes);

// Validation errors
app.use(function(err, req, res, next) {
  if (err instanceof ValidationError) {
    return res.status(err.statusCode).json(err)
  }
  if(err instanceof Forbidden) {
    return res.status(403).json({ error: true, message: err.message } )
  }
  if(err instanceof Unauthorised) {
    return res.status(401).json({ error: true, message: err.message } )
  }
  if(env == "development") {
    return res.status(500).json( { error: true, message: err.message, stack: err.stack } )
  }
  return res.status(500).json( { error: true, message: err.message } )
})

app.use(function (req, res, next) {
  res.status(404).json( { error: true, message: req.originalUrl+" not found" } )
})

module.exports = app;
