const Log = require('debug-level')
const curLoger = new Log('Logger')
class Logger {
  constructor(logName) {
    if(!logName) {
      curLoger.error(new Error("Log name is required"))
      return
    }
    this.logger = new Log(logName)
  }

  log(message) {
    try {
      this.logger.log(message)
    }
    catch(e) {
      curLoger.error(new Error(e.message))
    }
  }

  logInfo(message) {
    try {
      this.logger.info(message)
    }
    catch(e) {
      curLoger.error(new Error(e.message))
    }
  }

  logError(message) {
    try {
      this.logger.error(new Error(message))
    }
    catch(e) {
      curLoger.error(new Error(e.message))
    }
  }

  logFatal(message) {
    try {
      this.logger.fatal(new Error(message))
    }
    catch(e) {
      curLoger.error(new Error(e.message))
    }
  }

  logWarn(message) {
    try {
      this.logger.warn(message)
    }
    catch(e) {
      curLoger.error(new Error(e.message))
    }
  }
}

module.exports = Logger
