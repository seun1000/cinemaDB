const Toast = Swal.mixin({
  toast: true,
  position: 'top-end',
  showConfirmButton: false,
  timer: 3000,
  timerProgressBar: true,
  didOpen: (toast) => {
    toast.addEventListener('mouseenter', Swal.stopTimer)
    toast.addEventListener('mouseleave', Swal.resumeTimer)
  }
})

$(document).on('click', 'tr.headsAdd', function() {
  let tbody = $('#headsTable').find('tbody')
  let curTr = $(this)
  let html = `
    <tr>
      <td><input class="form-control" name="position" placeholder="Enter position name"></td>
      <td><input class="form-control" name="person" placeholder="Enter person name"></td>
      <td><input class="form-control" name="link" placeholder="Enter link"></td>
      <td><button type="button" class="btn btn-danger removeTr" style="color: #f7f7f7"><i class="fa fa-minus-circle"></i></button></td>
    </tr>
  `
  $(html).insertBefore(curTr)
})

$(document).on('click', 'tr.actorsAdd', function() {
  let tbody = $('#headsTable').find('tbody')
  let curTr = $(this)
  let html = `
    <tr>
      <td><input class="form-control" name="name" placeholder="Enter actor name"></td>
      <td><input class="form-control" name="link" placeholder="Enter link"></td>
      <td><button type="button" class="btn btn-danger removeTr" style="color: #f7f7f7"><i class="fa fa-minus-circle"></i></button></td>
    </tr>
  `
  $(html).insertBefore(curTr)
})

$(document).on('click', 'button.removeTr', function() {
  let tr = $(this).parent().parent()
  Swal.fire({
    icon: "warning",
    title: "Are you sure?",
    showConfirmButton: true,
    showCancelButton: true
  }).then((clicked) => {
    if(clicked.isConfirmed) {
      $(tr).remove()
    }
  })
})

$(document).on('change', 'input[name="poster"]', function() {
  let fileName = $(this).val()
  let label = $(this).prev('label')
  let help = $(this).next('small')
  $(help).text('File to be uploaded: '+fileName)
  $(label).find('i').removeClass('fa-upload').addClass('fa-times').css('color', 'red')
})

$('form').on('submit', function(e) {
  e.preventDefault()
  let val1 = $('input[name="title"]').val()
  let val2 = $('input[name="releaseDate"]').val()
  let errors = 0
  if(!val1) {
    errors++
    $('input[name="title"]').css('border', '3px solid red')
    setTimeout(() => {
      $('input[name="title"]').css('border', '1px solid #e9ecef')
    }, 3000)
  }
  if(!val2) {
    errors++
    $('input[name="releaseDate"]').css('border', '3px solid red')
    setTimeout(() => {
      $('input[name="releaseDate"]').css('border', '1px solid #e9ecef')
    }, 3000)
  }
  if(errors == 0) {
    let data = generateTableData()
    showLoader()
    let file = document.querySelector('input[name="poster"]').files[0];
    const form = new FormData()
    form.append('poster', file)
    form.append('title', data.title)
    form.append('releaseDate', data.releaseDate)
    form.append('ratings', data.ratings)
    form.append('heads', data.heads)
    form.append('actors', data.actors)
    $.ajax({
      url: "../../../v1/movies/",
      method: "POST",
      headers: { "Authorization": $.cookie('token') },
      cache: false,
      contentType: false,
      processData: false,
      data: form,
      success: function(res) {
        stopLoader()
        if(res.success) {
          showToast('success', res.message)
          window.location = "../"
        }
        else {
          showToast('success', res.message)
        }
      },
      error: function(err) {
        stopLoader()
        let res = err.responseJSON
        showToast('error', res.message)
      }
    })
  }
  else {
    showToast('error', 'Missing fields')
  }
})

function showToast(icon, title) {
  Toast.fire({
    icon: icon,
    title: title
  })
}

function showLoader() {
  $('div.loader').addClass('is-active')
}

function stopLoader() {
  $('div.loader').removeClass('is-active')
}

function generateTableData() {
  let movieData = { title: '', releaseDate: '', heads: [], actors: [] }
  movieData.title = $('input[name="title"]').val()
  movieData.releaseDate = $('input[name="releaseDate"]').val()
  movieData.ratings = $('input[name="ratings"]').val()

  // Get heads
  $("#headsTable").find('tbody').find('tr').each(function() {
    let trData = {}
    $(this).find('input').each(function() {
      let val = $(this).val()
      let name = $(this).attr('name')
      trData[name] = val
    })
    if(Object.values(trData).length > 0) {
      movieData.heads.push(trData)
    }
  })

  // Get actors
  $("#actorsTable").find('tbody').find('tr').each(function() {
    let trData = {}
    $(this).find('input').each(function() {
      let val = $(this).val()
      let name = $(this).attr('name')
      trData[name] = val
    })
    if(Object.values(trData).length > 0) {
      movieData.actors.push(trData)
    }
  })

  return movieData
}
