const Toast = Swal.mixin({
  toast: true,
  position: 'top-end',
  showConfirmButton: false,
  timer: 3000,
  timerProgressBar: true,
  didOpen: (toast) => {
    toast.addEventListener('mouseenter', Swal.stopTimer)
    toast.addEventListener('mouseleave', Swal.resumeTimer)
  }
})
function showToast(icon, title) {
  Toast.fire({
    icon: icon,
    title: title
  })
}

function showLoader() {
  $('div.loader').addClass('is-active')
}

function stopLoader() {
  $('div.loader').removeClass('is-active')
}

$(document).on('click', 'button.delete', function() {
  let id = $(this).data('id')
  Swal.fire({
    icon: "warning",
    title: "Are you sure?",
    showConfirmButton: true,
    showCancelButton: true
  }).then((clicked) => {
    if(clicked.isConfirmed) {
      showLoader()
      $.ajax({
        url: "../../v1/movies",
        method: "DELETE",
        headers: { "Authorization": $.cookie('token') },
        data: { id },
        success: function(res) {
          stopLoader()
          if(res.success) {
            showToast('success', res.message)
            window.location.reload()
          }
          else {
            showToast('success', res.message)
          }
        },
        error: function(err) {
          stopLoader()
          let res = err.responseJSON
          showToast('error', res.message)
        }
      })
    }
  })
})
