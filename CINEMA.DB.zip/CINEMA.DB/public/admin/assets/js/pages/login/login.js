const Toast = Swal.mixin({
  toast: true,
  position: 'top-end',
  showConfirmButton: false,
  timer: 3000,
  timerProgressBar: true,
  didOpen: (toast) => {
    toast.addEventListener('mouseenter', Swal.stopTimer)
    toast.addEventListener('mouseleave', Swal.resumeTimer)
  }
})

$('form').on('submit', function(e) {
  e.preventDefault()
  let val1 = $('input[name="username"]').val()
  let val2 = $('input[name="password"]').val()
  let errors = 0
  if(!val1) {
    errors++
    $('input[name="username"]').css('border', '3px solid red')
    setTimeout(() => {
      $('input[name="username"]').css('border', '1px solid #e9ecef')
    }, 3000)
  }
  if(!val2) {
    errors++
    $('input[name="password"]').css('border', '3px solid red')
    setTimeout(() => {
      $('input[name="password"]').css('border', '1px solid #e9ecef')
    }, 3000)
  }
  if(errors == 0) {
    let data = { username: val1, password: val2 }
    showLoader()
    $.ajax({
      url: "../../../v1/auth/login",
      method: "POST",
      data: data,
      success: function(res) {
        stopLoader()
        if(res.success) {
          $.cookie('token', res.token)
          window.location = "movies"
          showToast('success', res.message)
        }
        else {
          showToast('success', res.message)
        }
      },
      error: function(err) {
        stopLoader()
        let res = err.responseJSON
        showToast('error', res.message)
      }
    })
  }
  else {
    showToast('error', 'Missing fields')
  }
})

function showToast(icon, title) {
  Toast.fire({
    icon: icon,
    title: title
  })
}

function showLoader() {
  $('div.loader').addClass('is-active')
}

function stopLoader() {
  $('div.loader').removeClass('is-active')
}
